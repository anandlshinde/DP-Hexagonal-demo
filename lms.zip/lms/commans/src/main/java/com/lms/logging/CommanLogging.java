package com.lms.logging;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;

@Slf4j
public class CommanLogging {


    public static  void info(){
        String fullClassName=Thread.currentThread().getStackTrace()[2].getClassName();
        String methodName=Thread.currentThread().getStackTrace()[2].getMethodName();

        log.info(String.format("Method %s called of %s",methodName,fullClassName));

    }


    public static void info(String message,String fullClassName,String methodName){
        String[] classNameArr=fullClassName.split("\\.");
        String className=classNameArr[classNameArr.length-1];
        log.info(String.format("Method  called of "+className+" :: "+methodName+" :: "+message));
    }

    public static void error(String errorMessage){
        log.info(errorMessage);
    }
}
