package com.lms.ports.spi;

import com.lms.dto.BookDto;

import java.util.List;

public interface BookPersistencePort {

    public List<BookDto> getBooks();
}
