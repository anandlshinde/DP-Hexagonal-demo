package com.lms.service;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.lms.dto.BookDto;
import com.lms.logging.CommanLogging;
import com.lms.ports.api.BookServicePort;
import com.lms.ports.spi.BookPersistencePort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookServicePort {

    @Autowired
    private BookPersistencePort bookPersistencePort;


    @Override
    public List<BookDto> getBooks() {
        CommanLogging.info("GetBooks Logger print ",
                this.getClass().getName(),"getBooks");
        return this.bookPersistencePort.getBooks();
    }
}
