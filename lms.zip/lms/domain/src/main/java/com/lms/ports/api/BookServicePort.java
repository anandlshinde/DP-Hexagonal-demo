package com.lms.ports.api;

import com.lms.dto.BookDto;

import java.awt.print.Book;
import java.util.List;

public interface BookServicePort {

    public List<BookDto> getBooks();
}
