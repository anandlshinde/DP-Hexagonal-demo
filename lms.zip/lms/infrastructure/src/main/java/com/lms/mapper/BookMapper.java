package com.lms.mapper;

import com.lms.dto.BookDto;
import com.lms.entity.Book;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface BookMapper {

    BookMapper INTANCE= Mappers.getMapper(BookMapper.class);

    BookDto entityToDto(Book book);
    Book dtoToEntity(BookDto bookDto);
    List<BookDto> entityListToDtoList(List<Book> bookList);
    List<Book> dtoListToEntityList(List<BookDto> bookDtoList);
}
