package com.lms.adaptor;

import com.lms.dto.BookDto;
import com.lms.entity.Book;
import com.lms.mapper.BookMapper;
import com.lms.ports.spi.BookPersistencePort;
import com.lms.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

@Service
public class BookAdaptor implements BookPersistencePort {


    @Autowired
    private BookRepository bookRepository;




    @PostConstruct
    public void init(){
        Book book=new Book();
        book.setTitle("Spring Data JPA");
        book.setDescription("Data JPA Basics to Master");
        book.setPrice(500.00);
        this.bookRepository.save(book);
    }

    @Override
    public List<BookDto> getBooks() {
        List<Book> bookList = this.bookRepository.findAll();
        return BookMapper.INTANCE.entityListToDtoList(bookList);
        //return BookMapperimpl.BookEntityToBookDtoList(bookList);
    }
}
