package com.lms.controller;

import com.lms.dto.BookDto;
import com.lms.ports.api.BookServicePort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookController {

    private BookServicePort bookServicePort;

    @Autowired
   public BookController(BookServicePort bookServicePort){
        this.bookServicePort=bookServicePort;
    }

    @GetMapping("/books")
    public ResponseEntity<List<BookDto>> getBooks(){
        List<BookDto> books = this.bookServicePort.getBooks();
        return new ResponseEntity<>(books, HttpStatus.FOUND);
    }
}
