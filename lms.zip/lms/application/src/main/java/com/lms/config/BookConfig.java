package com.lms.config;

import com.lms.adaptor.BookAdaptor;
import com.lms.ports.api.BookServicePort;
import com.lms.ports.spi.BookPersistencePort;
import com.lms.service.BookServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BookConfig {



    @Bean
    public BookPersistencePort bookPersistencePort(){
        return new BookAdaptor();
    }

    @Autowired
    public BookServicePort bookServicePort(){
        return  new BookServiceImpl();
    }

}
